sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{onPress:function(e){debugger}}});
//# sourceMappingURL=Liability.js.map